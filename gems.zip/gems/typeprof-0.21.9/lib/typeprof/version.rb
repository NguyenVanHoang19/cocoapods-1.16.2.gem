module TypeProf
  VERSION = "0.21.9"
end
